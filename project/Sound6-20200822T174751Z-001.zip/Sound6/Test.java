public class Test 
{
  public static void main(String[] args) 
  { 
    int[] samples1 = {0,0,0,4,3,0,-6,6,12,1,0,4,-6,24,0,0,-6,0,0};
    Sound sound1 = new Sound(samples1);
          
    System.out.println("sound1 before limiting the amplitude");
    System.out.println(sound1);
    int changes = sound1.limitAmplitude(7);
    System.out.println("sound1 after limiting the amplitude");
    System.out.println(sound1);
    System.out.println(changes + " samples changed in sound1."); 
    
    int absolute = sound1.getHighestAmplitude();
    System.out.println(absolute);
    
    int lowest = sound1.getLowestSample();
    System.out.println(lowest);
    
    int match = sound1.countMatches(-6);
    System.out.println(match);
    
    double mean = sound1.mean();
    System.out.println(mean);
    
    int matches = sound1.identical();
    System.out.println(matches);
    
  }
 }
