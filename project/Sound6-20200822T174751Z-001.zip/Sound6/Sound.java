public class Sound 
{
  /** the array of values in this sound; guaranteed not to be null */
  private int[] samples;
  
  /**
   * @param soundSamples the array of values for constructing this sound;
   * guaranteed not to be null
   * */
  
  public Sound(int[] soundSamples) 
  {
    samples = soundSamples;
  }
  
  /** Chanes those values in this sound that have a value greater than limit.
    * Values greater than limit are changed to limit.
    * Values less than -limit are changed to -limit.
    * @param limit the amplitude limit
    * Precondition: limit &#8805; 0
    * @return the number of values in the sound that this method changed
    */
  
  public int limitAmplitude(int limit)
  {
    int changes = 0;
    for (int i = 0; i < samples.length; i++)
    {
      if (samples[i] > limit)
      {
        samples[i] = limit;
        changes++;
      }
      else if (samples[i] < -limit)
      {
        samples[i] = -limit;
        changes++;
      }
    }
    return changes;
  }
  
  /** Removes all silence from the beginning of this sound.
    * Silence is represented by a value of 0.
    * Precondition: samples contains at least one nonezero value
    * Postcondition: the length of samples reflects the removal of starting silence
    */
 public void trimSilenceFromBeginning()
  {
    int a = 0;
    while(samples[a] == 0)
      a++;
    
    int[] temp = new int[samples.length - a];
    
    for(int i = 0; i < temp.length; i++)    
      temp[i] = samples[a + i];
        
    samples = temp;
  }  
 
 /** 
  * @return the largest value in the sample array
  */
 public int getHighestSample()
 {
   int highest = samples[0];
   for(int i = 0; i < samples.length; i++)
   {          
     if(samples[i] > highest)
       highest = samples[i];
        }
   return highest;
 }
 
  /** 
  * @return the smallest value in the sample array
  */
 public int getLowestSample()
 {
   int lowest = samples[0];
   for(int num :samples)
   {     
     if(num < lowest)
       lowest = num;     
   }
   return lowest;
 }
 
  /**
  * @return the largest amplitude in the sample array
  */
 public int getHighestAmplitude()
 {
   if (Math.abs(getHighestSample()) > Math.abs(getLowestSample()))
     return Math.abs(getHighestSample());
   else
     return Math.abs(getLowestSample());
 }
 
 /**
  * @param num the value we are searching for
  * @return the number of times num occurs in the sample array
  */
 public int countMatches(int num)
 {
   int matches = 0;
   for(int a :samples)
   {
     if(a == num)
       matches++;
   }
   return matches;
 }
 
 public double mean()
 {
  double meanOfSample = 0.0;
  for(int a : samples)
  {
    meanOfSample = meanOfSample + a;
  }
  meanOfSample = meanOfSample / samples.length;
  return meanOfSample;
 }
 
 public int identical()
 {
   int count = 0;   
     for(int i = 1; i < samples.length; i++)
     {

       if(samples[i] == samples[i - 1])
          {
            count++;
          }
     }
   return count;
 }
  
public boolean isIncreasing()
{
  for (int i = 1; i < samples.length; i++)
    if(samples[i] <= samples[i - 1])
       return false;
  return true;
}

public boolean contains(int val)
{
  for(int a : samples)
    if(val == a)
       return true;
  return false;
}
 
 /**
  * @return a formatted output String of all sample values in this sound
  */
  public String toString()
  {
    String output = "";
    for (int i = 0; i < samples.length; i++)
    {
      output += samples[i];
      if (i != samples.length - 1)
        output += ", ";
    }
    return output;
   }
}
